## Judo
- [[Alice]]
- [[Batoul]]
- [[Clara]]
- [[Dilan]]
- [[Hamza]]

## Robotique
- [[Clara]]
- [[Dilan]]
- [[Eloise]]

## Musique
- [[Gregory]]
- [[Hamza]]

## Bibliothèque
- [[Gregory]]
- [[Fatah]]


