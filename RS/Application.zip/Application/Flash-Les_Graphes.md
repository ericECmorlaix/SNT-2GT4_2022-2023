#flashcards  

## Les graphes  

Un ==**graphe**== est un ensemble de ==**sommets**== pouvant être reliés entre eux par des ==**arêtes**==.  
  
### Exemples :
  
- Pour représenter un réseau routier, les **..........** sont les **villes**, et les **..........** sont les **routes** entre ces **villes**.
- Pour un graphe de réseau d’amis, les personnes sont représentés par les :: **..........**
- Pour un graphe de réseau d’amis, les liens d’amitié sont représentés par les :: **..........**
  
### Définitions :

La **..........**
??
Le minimum d'arêtes pour connecter deux sommets.

L'**..........** d'un sommet
??
La distance la plus grande qui existe entre un sommet et n'importe quel autre sommet du graphe.

Le **..........** d'un graphe
??
Le plus grand écartement de ses sommets.

Le **..........** d'un graphe
??
Le sommet qui a le plus petit écartement. 

Le **..........** d’un graphe
??
L’écartement de son centre ;
C’est aussi le plus petit écartement de ses sommets.  

En quoi consiste l'expérience de Milgram...
?
**...........................................**
**...........................................**