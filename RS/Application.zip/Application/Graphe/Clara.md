## Judo
- [[Batoul]]
- [[Dilan]]
- [[Hamza]]
-  [[Alice]]

## Robotique
- [[Dilan]]
- [[Eloise]]

