## Judo
- [[Batoul]]
- [[Clara]]
- [[Hamza]]
-  [[Alice]]

## Robotique
- [[Clara]]
- [[Eloise]]

