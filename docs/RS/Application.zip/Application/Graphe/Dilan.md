## Judo
- [[Batoul]]
- [[Clara]]
- [[Hamza]]
-  [[Alice]]

## Robotique
- [[Clara]]
- [[Eloïse]]

