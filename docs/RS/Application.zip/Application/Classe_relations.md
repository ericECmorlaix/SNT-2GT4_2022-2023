## Judo
- [[Alice]]
- [[Batoul]]
- [[Clara]]
- [[Dilan]]
- [[Hamza]]

## Robotique
- [[Clara]]
- [[Dilan]]
- [[Eloïse]]

## Musique
- [[Grégory]]
- [[Hamza]]

## Bibliothèque
- [[Grégory]]
- [[Fatah]]


